<!-- VISTA que muestra un mensaje si no se ha introducido alguna condición en buscar -->	

<div class="row">
    <!-- 1ª COLUMNA -->
    <div class="col-md-1"></div>
    <!-- 2ª COLUMNA -->
    <div class="col-md-10">

        <div class="panel panel-default">

            <div class="panel-body">

                <h3 class="text-center text-warning"><b>DEBES INTRODUCIR ALGUNA CONDICIÓN PARA BUSCAR</b></h3>

            </div><!-- fin panel body-->

        </div><!-- fin panel panel-default -->

    </div><!-- fin 2ª columna -->

    <!-- 3ª COLUMNA -->
    <div class="col-md-1"></div>
</div> <!--Fin row-->
