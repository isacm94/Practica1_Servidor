<!-- VISTA que muestra un mensaje cuando no hay datos de cumplan las condiciones de buscar -->


<div class="row">
    <!-- 1ª COLUMNA -->
    <div class="col-md-1"></div>
    <!-- 2ª COLUMNA -->
    <div class="col-md-10">

        <div class="panel panel-default">

            <div class="panel-body">

                <h3 class="text-center text-warning"><b>NO EXISTEN DATOS GUARDADOS CON ESAS CARACTERÍSTICAS</b></h3>

            </div><!-- fin panel body-->

        </div><!-- fin panel panel-default -->

    </div><!-- fin 2ª columna -->

    <!-- 3ª COLUMNA -->
    <div class="col-md-1"></div>
</div> <!--Fin row-->


