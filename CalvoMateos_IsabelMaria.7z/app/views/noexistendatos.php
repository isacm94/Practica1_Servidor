<!-- VISTA que muestra un mensaje cuando no hay tareas guardados en la Base de Datos -->	

<div class="row" style="margin-top: 10%; margin-bottom: 10%;">
    <!-- 1ª COLUMNA -->
    <div class="col-md-1"></div>
    <!-- 2ª COLUMNA -->
    <div class="col-md-10">

        <div class="panel panel-default">

            <div class="panel-body">

                <h3 class="text-center text-warning"><b>NO EXISTEN DATOS GUARDADOS</b></h3>

            </div><!-- fin panel body-->

        </div><!-- fin panel panel-default -->

    </div><!-- fin 2ª columna -->

    <!-- 3ª COLUMNA -->
    <div class="col-md-1"></div>
</div> <!--Fin row-->
