<!-- Pie de la aplicación, mostrado en todas las páginas -->

<!-- Pie -->
<footer class="text-center">
    <div class="footer-above">
        <div class="container">
            <div class="row">
                <div class="footer-col col-md-12">
                    <h3>Copyright &copy;</h3>
                    <p>Isabel María Calvo Mateos</p>
                    <p>Práctica Servidor</p>
                </div>
            </div>
        </div>

</footer>

<!-- jQuery -->
<script src="../assets/bootstrap/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
