<!-- PÁGINA PRINCIPAL -->
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <img class="img-responsive" src="../assets/bootstrap/img/profile.png" alt="">
            <div class="intro-text">
                <span class="name" style="color: white;">PACO GARDEN</span>
                <hr class="star-light">
            </div>
        </div>
    </div>
</div>
