<!-- Página de error 404-->

<div class="row" >
    <!-- 1ª COLUMNA -->
    <div class="col-md-1"></div>
    <!-- 2ª COLUMNA -->
    <div class="col-md-10">

        <div class="panel panel-default" style="margin-top: 29%; margin-bottom: 23%;">

            <div class="panel-body">

                <h3 class="text-center text-danger">Error 404: Recurso no encontrado </h3>
                <!--No existe el fichero: <?= $file ?> -->
            </div><!-- fin panel body-->

        </div><!-- fin panel panel-default -->

    </div><!-- fin 2ª columna -->

    <!-- 3ª COLUMNA -->
    <div class="col-md-1"></div>
</div> <!--Fin row-->

